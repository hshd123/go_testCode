package controllers

import (
	"DMFlower/models"
	"github.com/astaxie/beego"
)

type Constellations struct {
	beego.Controller
}

func (this *Constellations) GetConList() {
	c1 := models.ConDesc{}
	l1 := c1.GetConDescList()
	d1 := models.Data{
		Code:   0,
		Result: l1,
		Msg:    "succ",
	}
	this.Data["json"] = d1
	this.ServeJSON(false)
}

func (this *Constellations) GetStarList() {
	c1 := models.Conste{}
	l1 := c1.GetAllModel()
	d1 := models.Data{
		Code:   0,
		Result: l1,
		Msg:    "succ",
	}
	this.Data["json"] = d1
	this.ServeJSON(false)
}

func (this *Constellations) GetCarouseList() {
	c1 := models.Carousel{}
	l1 := c1.GetAllCarouse()
	d1 := models.Data{}
	if l := len(l1); l != 0 {
		d1.Code = 0
		d1.Result = l1
		d1.Msg = "succ"
	} else {
		d1.Code = 100001
		d1.Result = nil
		d1.Msg = "正在抢救中..."
	}

	this.Data["json"] = d1
	this.ServeJSON(false)
}

func (this *Constellations) GetFlowerList() {
	f1 := models.Flower{}
	d1 := models.Data{}
	l1 := f1.GetAllFlower()
	if l := len(l1); l != 0 {
		d1.Code = 0
		d1.Msg = "succ"
		d1.Result = l1

	} else {
		d1.Code = 100001
		d1.Result = nil
		d1.Msg = "正在抢救中..."
	}
	this.Data["json"] = d1
	this.ServeJSON(false)
}

//缺少前期验证
//redis 缓存

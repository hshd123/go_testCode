package controllers

import (
	"fmt"
	"github.com/astaxie/beego"
)

type User struct {
	Name   string `json:"name"`
	Age    int    `json:"age"`
	UserId string `json:"userId"`
	Mobile string `json:"mobile"`
}

// Operations about Users
type UserController struct {
	beego.Controller
}

var Name string = ""

func (this *UserController) Prepare() {
	fmt.Println("this func is prepre")
	fmt.Println(" name --- ", Name)
}

func (this *UserController) Login() {
	u1 := User{
		Name:   "张三",
		Age:    28,
		Mobile: "17263847237",
		UserId: "1728372",
	}
	fmt.Println("获取到的参数 -- ", this.Input().Get("userId"))
	this.Data["json"] = u1
	this.ServeJSON()
}

package models

import "github.com/go-xorm/xorm"
import (
	"fmt"
	"github.com/astaxie/beego"
	_ "github.com/go-sql-driver/mysql"
	"github.com/go-xorm/core"
	"os"
)

type Carousel struct {
	Title       string `json:"title" xorm:"name title"`
	ContextText string `json:"contextText"`
	CreatedAt   string `json:"createdAt"`
	ImageName   string `json:"imageName"`
	SubTitle    string `json:"subTitle" xorm:"name subTitle LONGTEXT default " " "`
	Url         string `json:"url"`
	Id          int64  `json:"id" xorm:" INT default 0 autoincr "`
}

type Conste struct {
	StarName  string `json:"starName" xorm:"name starTime"`
	Time      string `json:"time" xorm:"name c_time"`
	ImageName string `json:"imageName" xorm:"name imageName"`
	Id        int    `json:"id" xorm："name id pk"`
}

type ConDesc struct {
	Title       string `json:"title" xorm:"name title"`
	ContextText string `json:"contextText" xorm:"name contextText LONGTEXT default " " "`
	ImageName   string `json:"imageName" xorm:"name imageName"`
	SubTitle    string `json:"subTitle" xorm:"name subTitle"`
}


type FlowerItem struct {
	ImageName   string `json:"imageName"`
	Title       string `json:"title"`
	SubTitle    string `json:"subTitle"`
	ContextText string `json:"contextText"`
}

type Flower struct {
	Header  string       `json:"header"`
	Flowers []FlowerItem `json:"flowers"`
}

type Data struct {
	Code   int         `json:"code"`
	Msg    string      `json:"msg"`
	Result interface{} `json:"result"`
}

var myEngin *xorm.Engine

func RegistDB() *xorm.Engine {
	engine, err := xorm.NewEngine("mysql", "root:123456@/test_db?charset=utf8")
	if err != nil {
		beego.Debug(err.Error())
		os.Exit(-1)
	}
	err = engine.Ping()
	if err != nil {
		beego.BeeLogger.Debug(err.Error())
		beego.Info(err.Error())
	}
	engine.ShowExecTime(true)
	engine.ShowSQL(true)
	engine.SetMaxOpenConns(20)
	engine.SetMaxIdleConns(20)
	engine.SetMapper(core.SameMapper{})
	engine.Charset("utf8mb4")
	return engine
}

func init() {
	myEngin = RegistDB()
}

func (this *ConDesc) GetConDescList() []ConDesc {
	l1 := make([]ConDesc, 0)
	err := myEngin.Find(&l1)
	if err != nil {
		beego.Debug(err.Error())
		fmt.Println(err.Error())
	}
	return l1
}

func (this * Conste) GetAllModel() []Conste {
	c1 := make([]Conste, 0)
	err := myEngin.Find(&c1)
	if err != nil {
		beego.Debug(err.Error())
		fmt.Println(err.Error())
	}
	return c1
}

func (this * Carousel) GetAllCarouse() []Carousel {
	l1 := make([]Carousel,0)
	err := myEngin.Find(&l1)
	if err != nil {
		beego.Debug(err.Error())
		fmt.Println(err.Error())
	}
	return l1
}

func (this * Flower) GetAllFlower()[]Flower  {
	l1 := make([]Flower,0)
	err := myEngin.Find(&l1)
	if err != nil {
		fmt.Println("GetAllFlower  err ", err.Error())
		beego.Debug(err.Error())
	}
	return l1
}
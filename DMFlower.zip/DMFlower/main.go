package main

import (
	_ "DMFlower/routers"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
)

func main() {
	if beego.BConfig.RunMode == "dev" {
		beego.BConfig.WebConfig.DirectoryIndex = true
		beego.BConfig.WebConfig.StaticDir["/swagger"] = "swagger"
	}
	beego.BeeLogger.EnableFuncCallDepth(true)
	beego.BeeLogger.SetLogger(logs.AdapterFile, `{
		"filename":"dmflower.log",
		 "maxsize":10000000000,
		 "level":7,
		 "maxlines":1000000000,
		 "daily":true,
		 "maxdays":1000000
		 }`)
	beego.BeeLogger.Async(1000e3)
	beego.Run()
}


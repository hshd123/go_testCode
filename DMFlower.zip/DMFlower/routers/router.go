// @APIVersion 1.0.0
// @Title beego Test API
// @Description beego has a very cool tools to autogenerate documents for your API
// @Contact astaxie@gmail.com
// @TermsOfServiceUrl http://beego.me/
// @License Apache 2.0
// @LicenseUrl http://www.apache.org/licenses/LICENSE-2.0.html
package routers

import (
	"DMFlower/controllers"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/context"
)

func init() {
	beego.Router("/user/login", &controllers.UserController{}, "get,post:Login")
	beego.Router("/cons/desclist", &controllers.Constellations{}, "get,post:GetConList")
	beego.Router("/cons/starlist", &controllers.Constellations{}, "get,post:GetStarList")
	beego.Router("/cons/carouselist", &controllers.Constellations{}, "get,post:GetCarouseList")
	beego.Router("/cons/flowers", &controllers.Constellations{}, "get,post:GetFlowerList")
	beego.Get("/", func(ctx *context.Context) {
		ctx.Abort(404, "not found")
	})
}
